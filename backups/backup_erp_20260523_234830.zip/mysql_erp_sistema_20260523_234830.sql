-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: erp_sistema
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `erp_sistema`
--

/*!40000 DROP DATABASE IF EXISTS `erp_sistema`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `erp_sistema` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;

USE `erp_sistema`;

--
-- Table structure for table `erp_config`
--

DROP TABLE IF EXISTS `erp_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `erp_config` (
  `clave` varchar(100) NOT NULL,
  `valor` text DEFAULT NULL,
  `actualizado` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`clave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erp_config`
--

LOCK TABLES `erp_config` WRITE;
/*!40000 ALTER TABLE `erp_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `erp_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `erp_ficheros`
--

DROP TABLE IF EXISTS `erp_ficheros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `erp_ficheros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `nombre_original` varchar(500) DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `tipo_detectado` varchar(50) DEFAULT NULL,
  `tamano_bytes` bigint(20) DEFAULT NULL,
  `esta_en_disco` tinyint(1) DEFAULT 0,
  `ruta_disco` varchar(1000) DEFAULT NULL,
  `tabla_origen` varchar(100) DEFAULT NULL,
  `fecha_subida` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erp_ficheros`
--

LOCK TABLES `erp_ficheros` WRITE;
/*!40000 ALTER TABLE `erp_ficheros` DISABLE KEYS */;
/*!40000 ALTER TABLE `erp_ficheros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `erp_meta_columnas`
--

DROP TABLE IF EXISTS `erp_meta_columnas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `erp_meta_columnas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tabla_id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `nullable` tinyint(1) DEFAULT 1,
  `es_contrasena` tinyint(1) DEFAULT 0,
  `es_visible` tinyint(1) DEFAULT 1,
  `es_sensible` tinyint(1) DEFAULT 0,
  `es_archivo` tinyint(1) DEFAULT 0,
  `autoincremental` tinyint(1) DEFAULT 0,
  `unico` tinyint(1) DEFAULT 0,
  `valor_defecto` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tabla_id` (`tabla_id`),
  CONSTRAINT `erp_meta_columnas_ibfk_1` FOREIGN KEY (`tabla_id`) REFERENCES `erp_meta_tablas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erp_meta_columnas`
--

LOCK TABLES `erp_meta_columnas` WRITE;
/*!40000 ALTER TABLE `erp_meta_columnas` DISABLE KEYS */;
INSERT INTO `erp_meta_columnas` VALUES (1,1,'id','ENTERO',0,0,1,0,0,1,1,NULL),(2,1,'correo_electronico','TEXTO_CORTO',0,0,1,0,0,0,1,NULL),(3,1,'nombre','TEXTO_CORTO',0,0,1,0,0,0,0,NULL),(4,1,'primer_apellido','TEXTO_CORTO',0,0,1,0,0,0,0,NULL),(5,1,'segundo_apellido','TEXTO_CORTO',1,0,1,0,0,0,0,NULL),(6,1,'dni_nie','TEXTO_CORTO',0,0,1,0,0,0,1,NULL),(7,1,'telefono','TEXTO_CORTO',1,0,1,0,0,0,0,NULL),(8,1,'direccion','TEXTO_CORTO',1,0,1,0,0,0,0,NULL),(9,1,'iban','TEXTO_CORTO',1,0,1,0,0,0,0,NULL),(10,1,'nss','TEXTO_CORTO',1,0,1,0,0,0,0,NULL),(11,1,'cargo','TEXTO_CORTO',1,0,1,0,0,0,0,NULL),(12,1,'foto_url','ARCHIVO',1,0,1,0,1,0,0,NULL),(13,1,'user_id','ENTERO',1,0,1,0,0,0,0,NULL),(14,2,'id','ENTERO',0,0,1,0,0,1,1,NULL),(15,2,'nombre','TEXTO_CORTO',0,0,1,0,0,0,0,NULL),(16,2,'descripcion','TEXTO_LARGO',1,0,1,0,0,0,0,NULL),(17,2,'referencia','TEXTO_CORTO',1,0,1,0,0,0,1,NULL),(18,2,'cantidad','ENTERO',1,0,1,0,0,0,0,NULL),(19,2,'precio','DECIMAL',0,0,1,0,0,0,0,NULL),(20,2,'imagen','ARCHIVO',1,0,1,0,1,0,0,NULL),(21,2,'esta_agotado','BINARIO',0,0,1,0,0,0,0,NULL),(22,3,'id','ENTERO',0,0,1,0,0,1,1,NULL),(23,3,'nombre','TEXTO_CORTO',0,0,1,0,0,0,0,NULL),(24,3,'apellido','TEXTO_CORTO',1,0,1,0,0,0,0,NULL),(25,3,'cif_nif','TEXTO_CORTO',0,0,1,0,0,0,1,NULL),(26,3,'telefono','TEXTO_CORTO',1,0,1,0,0,0,0,NULL),(27,3,'email','TEXTO_CORTO',1,0,1,0,0,0,0,NULL),(28,3,'direccion','TEXTO_LARGO',1,0,1,0,0,0,0,NULL),(29,3,'creado_en','FECHA_HORA',0,0,1,0,0,0,0,NULL),(30,3,'user_id','ENTERO',1,0,1,0,0,0,0,NULL),(31,4,'id','ENTERO',0,0,1,0,0,1,1,NULL),(32,4,'nombre','TEXTO_CORTO',0,0,1,0,0,0,0,NULL),(33,4,'email','TEXTO_CORTO',0,0,1,0,0,0,0,NULL),(34,4,'descripcion','TEXTO_LARGO',0,0,1,0,0,0,0,NULL),(35,4,'fecha','FECHA_HORA',0,0,1,0,0,0,0,NULL),(36,5,'id','ENTERO',0,0,1,0,0,1,1,NULL),(37,5,'dni_cliente','TEXTO_CORTO',0,0,1,1,0,0,0,NULL),(38,5,'documento_adjunto','ARCHIVO',1,0,1,0,1,0,0,NULL);
/*!40000 ALTER TABLE `erp_meta_columnas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `erp_meta_relaciones`
--

DROP TABLE IF EXISTS `erp_meta_relaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `erp_meta_relaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `tabla_origen` int(11) NOT NULL,
  `fk_columna` varchar(100) NOT NULL,
  `tabla_destino` varchar(100) NOT NULL,
  `cardinalidad` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tabla_origen` (`tabla_origen`),
  CONSTRAINT `erp_meta_relaciones_ibfk_1` FOREIGN KEY (`tabla_origen`) REFERENCES `erp_meta_tablas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erp_meta_relaciones`
--

LOCK TABLES `erp_meta_relaciones` WRITE;
/*!40000 ALTER TABLE `erp_meta_relaciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `erp_meta_relaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `erp_meta_tablas`
--

DROP TABLE IF EXISTS `erp_meta_tablas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `erp_meta_tablas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `modulo_id` int(11) DEFAULT NULL,
  `nombre_logico` varchar(100) NOT NULL,
  `nombre_amigable` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre_logico` (`nombre_logico`),
  KEY `modulo_id` (`modulo_id`),
  CONSTRAINT `erp_meta_tablas_ibfk_1` FOREIGN KEY (`modulo_id`) REFERENCES `erp_modulos` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erp_meta_tablas`
--

LOCK TABLES `erp_meta_tablas` WRITE;
/*!40000 ALTER TABLE `erp_meta_tablas` DISABLE KEYS */;
INSERT INTO `erp_meta_tablas` VALUES (1,1,'empleados','Gestion de Empleados'),(2,1,'productos','Catalogo de Productos'),(3,1,'clientes','Cartera de Clientes'),(4,1,'incidencias','Gestion de Incidencias'),(5,2,'pedidos','Gestión de Pedidos');
/*!40000 ALTER TABLE `erp_meta_tablas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `erp_modulos`
--

DROP TABLE IF EXISTS `erp_modulos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `erp_modulos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `icono` varchar(50) DEFAULT '?',
  `icon_type` varchar(20) DEFAULT 'emote',
  `habilitado` tinyint(1) DEFAULT 1,
  `orden` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erp_modulos`
--

LOCK TABLES `erp_modulos` WRITE;
/*!40000 ALTER TABLE `erp_modulos` DISABLE KEYS */;
INSERT INTO `erp_modulos` VALUES (1,'Gestion Central','⚙️','emote',1,1),(2,'Ventas','🛒','emote',1,1);
/*!40000 ALTER TABLE `erp_modulos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `erp_roles`
--

DROP TABLE IF EXISTS `erp_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `erp_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erp_roles`
--

LOCK TABLES `erp_roles` WRITE;
/*!40000 ALTER TABLE `erp_roles` DISABLE KEYS */;
INSERT INTO `erp_roles` VALUES (1,'admin','Administrador con acceso total'),(2,'empleado','Empleado con acceso basico'),(3,'cliente','Cliente con acceso a la tienda');
/*!40000 ALTER TABLE `erp_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `erp_roles_permisos`
--

DROP TABLE IF EXISTS `erp_roles_permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `erp_roles_permisos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rol` varchar(50) NOT NULL,
  `tabla` varchar(100) NOT NULL,
  `puede_ver` tinyint(1) DEFAULT 0,
  `puede_crear` tinyint(1) DEFAULT 0,
  `puede_editar` tinyint(1) DEFAULT 0,
  `puede_eliminar` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_rol_tabla` (`rol`,`tabla`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erp_roles_permisos`
--

LOCK TABLES `erp_roles_permisos` WRITE;
/*!40000 ALTER TABLE `erp_roles_permisos` DISABLE KEYS */;
/*!40000 ALTER TABLE `erp_roles_permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `erp_users`
--

DROP TABLE IF EXISTS `erp_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `erp_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `contrasena` char(60) NOT NULL,
  `rol_id` int(11) DEFAULT NULL,
  `tipo` enum('empleado','cliente') NOT NULL DEFAULT 'empleado',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_users_rol` (`rol_id`),
  CONSTRAINT `erp_users_ibfk_1` FOREIGN KEY (`rol_id`) REFERENCES `erp_roles` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_users_rol` FOREIGN KEY (`rol_id`) REFERENCES `erp_roles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erp_users`
--

LOCK TABLES `erp_users` WRITE;
/*!40000 ALTER TABLE `erp_users` DISABLE KEYS */;
INSERT INTO `erp_users` VALUES (1,'admin@empresa.com','$2a$10$7sl9Tja6CnShoIxoZXc3O.keT8iz8pK0hM6QAUNTGMY.Kxlcu4wT6',1,'empleado',1);
/*!40000 ALTER TABLE `erp_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'erp_sistema'
--

--
-- Dumping routines for database 'erp_sistema'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-23 23:48:30
